#!/bin/sh
cd "$(dirname "$0")"
python3 "towerdef.py"
